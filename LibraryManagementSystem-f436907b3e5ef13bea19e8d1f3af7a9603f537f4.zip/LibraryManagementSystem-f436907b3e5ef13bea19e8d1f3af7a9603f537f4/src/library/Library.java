package library;

import library.exceptions.*;

import java.time.LocalDate;
import java.util.*;

/**
 * Central engine of the system. Coordinates the three functional
 * modules described in the project report:
 *   1. Catalog Management  (add/update/search/remove books)
 *   2. Member Management   (register/remove members)
 *   3. Circulation (Issue/Return) with automatic fine calculation
 *
 * All state is kept in memory (HashMap for O(1) lookup) and mirrored
 * to disk via FileManager so data survives between runs.
 */
public class Library {
    private static final String BOOKS_FILE = "data/books.txt";
    private static final String MEMBERS_FILE = "data/members.txt";
    private static final String TRANSACTIONS_FILE = "data/transactions.txt";

    private final Map<String, Book> catalog = new HashMap<>();
    private final Map<String, Member> members = new HashMap<>();
    private final Map<String, Transaction> transactions = new HashMap<>();
    private int transactionCounter = 1;

    public Library() {
        loadAll();
    }

    // ---------- Module 1: Catalog Management ----------

    public void addBook(Book book) throws DuplicateEntryException {
        if (catalog.containsKey(book.getIsbn())) {
            throw new DuplicateEntryException("A book with ISBN " + book.getIsbn() + " already exists.");
        }
        catalog.put(book.getIsbn(), book);
        Logger.log("Book added: " + book.getIsbn() + " - " + book.getTitle());
        saveBooks();
    }

    public Book findBook(String isbn) throws BookNotFoundException {
        Book book = catalog.get(isbn);
        if (book == null) {
            throw new BookNotFoundException("No book found with ISBN " + isbn);
        }
        return book;
    }

    public List<Book> searchByTitle(String keyword) {
        List<Book> results = new ArrayList<>();
        for (Book b : catalog.values()) {
            if (b.getTitle().toLowerCase().contains(keyword.toLowerCase())) {
                results.add(b);
            }
        }
        Collections.sort(results); // uses Book.compareTo -> alphabetical by title
        return results;
    }

    public List<Book> allBooksSorted() {
        List<Book> all = new ArrayList<>(catalog.values());
        Collections.sort(all);
        return all;
    }

    public void removeBook(String isbn) throws BookNotFoundException {
        if (!catalog.containsKey(isbn)) {
            throw new BookNotFoundException("No book found with ISBN " + isbn);
        }
        catalog.remove(isbn);
        Logger.log("Book removed: " + isbn);
        saveBooks();
    }

    // ---------- Module 2: Member Management ----------

    public void registerMember(Member member) throws DuplicateEntryException {
        if (members.containsKey(member.getId())) {
            throw new DuplicateEntryException("A member with ID " + member.getId() + " already exists.");
        }
        members.put(member.getId(), member);
        Logger.log("Member registered: " + member.getId() + " - " + member.getName());
        saveMembers();
    }

    public Member findMember(String memberId) throws MemberNotFoundException {
        Member m = members.get(memberId);
        if (m == null) {
            throw new MemberNotFoundException("No member found with ID " + memberId);
        }
        return m;
    }

    public List<Member> allMembers() {
        return new ArrayList<>(members.values());
    }

    public void removeMember(String memberId) throws MemberNotFoundException {
        Member m = members.get(memberId);
        if (m == null) {
            throw new MemberNotFoundException("No member found with ID " + memberId);
        }
        if (m.getBooksIssuedCount() > 0) {
            throw new IllegalStateException("Cannot remove member with unreturned books.");
        }
        members.remove(memberId);
        Logger.log("Member removed: " + memberId);
        saveMembers();
    }

    // ---------- Module 3: Circulation (Issue / Return) ----------

    public Transaction issueBook(String isbn, String memberId)
            throws BookNotFoundException, MemberNotFoundException, BookNotAvailableException {
        Book book = findBook(isbn);
        Member member = findMember(memberId);

        if (!book.isAvailable()) {
            throw new BookNotAvailableException("\"" + book.getTitle() + "\" has no copies available right now.");
        }
        if (!member.canBorrow()) {
            throw new BookNotAvailableException(member.getName() + " has already reached the borrowing limit of "
                    + Member.MAX_BOOKS_ALLOWED + " books.");
        }

        book.issueCopy();
        member.incrementBooksIssued();

        String txnId = "T" + String.format("%04d", transactionCounter++);
        Transaction txn = new Transaction(txnId, isbn, memberId, LocalDate.now());
        transactions.put(txnId, txn);

        Logger.log("Issued: " + isbn + " to member " + memberId + " (txn " + txnId + ")");
        saveAll();
        return txn;
    }

    public double returnBook(String transactionId) throws BookNotFoundException, MemberNotFoundException {
        Transaction txn = transactions.get(transactionId);
        if (txn == null || txn.isReturned()) {
            throw new BookNotFoundException("No active loan found with transaction ID " + transactionId);
        }
        Book book = findBook(txn.getIsbn());
        Member member = findMember(txn.getMemberId());

        double fine = txn.markReturned(LocalDate.now());
        book.returnCopy();
        member.decrementBooksIssued();

        Logger.log("Returned: " + txn.getIsbn() + " by member " + txn.getMemberId()
                + " (fine: " + fine + ")");
        saveAll();
        return fine;
    }

    public List<Transaction> activeLoansForMember(String memberId) {
        List<Transaction> active = new ArrayList<>();
        for (Transaction t : transactions.values()) {
            if (t.getMemberId().equals(memberId) && !t.isReturned()) {
                active.add(t);
            }
        }
        return active;
    }

    public List<Transaction> allTransactions() {
        return new ArrayList<>(transactions.values());
    }

    // ---------- Persistence ----------

    private void saveBooks() {
        FileManager.writeAll(BOOKS_FILE, new ArrayList<>(catalog.values()));
    }

    private void saveMembers() {
        FileManager.writeAll(MEMBERS_FILE, new ArrayList<>(members.values()));
    }

    private void saveTransactions() {
        FileManager.writeAll(TRANSACTIONS_FILE, new ArrayList<>(transactions.values()));
    }

    private void saveAll() {
        saveBooks();
        saveMembers();
        saveTransactions();
    }

    private void loadAll() {
        for (Book b : FileManager.readAll(BOOKS_FILE, Book::fromFileLine)) {
            catalog.put(b.getIsbn(), b);
        }
        for (Member m : FileManager.readAll(MEMBERS_FILE, Member::fromFileLine)) {
            members.put(m.getId(), m);
        }
        for (Transaction t : FileManager.readAll(TRANSACTIONS_FILE, Transaction::fromFileLine)) {
            transactions.put(t.getTransactionId(), t);
            int num = Integer.parseInt(t.getTransactionId().substring(1));
            if (num >= transactionCounter) {
                transactionCounter = num + 1;
            }
        }
        Logger.log("Data loaded: " + catalog.size() + " books, " + members.size()
                + " members, " + transactions.size() + " transactions.");
    }
}
