package library;

/**
 * Represents a book title in the catalog. A single Book record tracks
 * the total number of copies owned and how many are currently
 * available, so multiple members can hold copies of the same title.
 */
public class Book implements Persistable, Comparable<Book> {
    private String isbn;
    private String title;
    private String author;
    private String genre;
    private int totalCopies;
    private int availableCopies;

    public Book(String isbn, String title, String author, String genre, int totalCopies, int availableCopies) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.totalCopies = totalCopies;
        this.availableCopies = availableCopies;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getGenre() {
        return genre;
    }

    public int getTotalCopies() {
        return totalCopies;
    }

    public int getAvailableCopies() {
        return availableCopies;
    }

    public boolean isAvailable() {
        return availableCopies > 0;
    }

    public void issueCopy() {
        if (availableCopies > 0) {
            availableCopies--;
        }
    }

    public void returnCopy() {
        if (availableCopies < totalCopies) {
            availableCopies++;
        }
    }

    public void addCopies(int count) {
        totalCopies += count;
        availableCopies += count;
    }

    @Override
    public int compareTo(Book other) {
        return this.title.compareToIgnoreCase(other.title);
    }

    @Override
    public String toFileLine() {
        return String.join("|", isbn, title, author, genre,
                String.valueOf(totalCopies), String.valueOf(availableCopies));
    }

    public static Book fromFileLine(String line) {
        String[] p = line.split("\\|");
        return new Book(p[0], p[1], p[2], p[3], Integer.parseInt(p[4]), Integer.parseInt(p[5]));
    }

    @Override
    public String toString() {
        return String.format("%-13s %-30s %-20s %-12s %d/%d available",
                isbn, title, author, genre, availableCopies, totalCopies);
    }
}
