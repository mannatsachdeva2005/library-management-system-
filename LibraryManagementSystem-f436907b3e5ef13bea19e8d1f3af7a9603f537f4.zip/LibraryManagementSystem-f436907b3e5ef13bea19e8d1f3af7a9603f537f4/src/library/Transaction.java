package library;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

/**
 * Records a single issue/return event linking a Member to a Book.
 * Owns the fine calculation logic for overdue returns.
 */
public class Transaction implements Persistable {
    public static final int LOAN_PERIOD_DAYS = 14;
    public static final double FINE_PER_DAY = 5.0; // currency units per day overdue

    private static final DateTimeFormatter FMT = DateTimeFormatter.ISO_LOCAL_DATE;

    private String transactionId;
    private String isbn;
    private String memberId;
    private LocalDate issueDate;
    private LocalDate dueDate;
    private LocalDate returnDate; // null while the book is still out
    private boolean returned;

    public Transaction(String transactionId, String isbn, String memberId, LocalDate issueDate) {
        this.transactionId = transactionId;
        this.isbn = isbn;
        this.memberId = memberId;
        this.issueDate = issueDate;
        this.dueDate = issueDate.plusDays(LOAN_PERIOD_DAYS);
        this.returnDate = null;
        this.returned = false;
    }

    // Full constructor used when reloading from file
    public Transaction(String transactionId, String isbn, String memberId,
                        LocalDate issueDate, LocalDate dueDate, LocalDate returnDate, boolean returned) {
        this.transactionId = transactionId;
        this.isbn = isbn;
        this.memberId = memberId;
        this.issueDate = issueDate;
        this.dueDate = dueDate;
        this.returnDate = returnDate;
        this.returned = returned;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getMemberId() {
        return memberId;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public boolean isReturned() {
        return returned;
    }

    /**
     * Marks the loan as returned on the given date and returns the
     * fine owed (0 if returned on or before the due date).
     */
    public double markReturned(LocalDate onDate) {
        this.returnDate = onDate;
        this.returned = true;
        return calculateFine(onDate);
    }

    public double calculateFine(LocalDate onDate) {
        long overdueDays = ChronoUnit.DAYS.between(dueDate, onDate);
        return overdueDays > 0 ? overdueDays * FINE_PER_DAY : 0.0;
    }

    @Override
    public String toFileLine() {
        return String.join("|",
                transactionId, isbn, memberId,
                issueDate.format(FMT),
                dueDate.format(FMT),
                returnDate == null ? "-" : returnDate.format(FMT),
                String.valueOf(returned));
    }

    public static Transaction fromFileLine(String line) {
        String[] p = line.split("\\|");
        LocalDate ret = p[5].equals("-") ? null : LocalDate.parse(p[5], FMT);
        return new Transaction(p[0], p[1], p[2],
                LocalDate.parse(p[3], FMT), LocalDate.parse(p[4], FMT), ret, Boolean.parseBoolean(p[6]));
    }

    @Override
    public String toString() {
        String status = returned ? ("Returned " + returnDate) : ("Due " + dueDate);
        return String.format("%-8s ISBN:%-10s Member:%-8s Issued:%-12s %s",
                transactionId, isbn, memberId, issueDate, status);
    }
}
