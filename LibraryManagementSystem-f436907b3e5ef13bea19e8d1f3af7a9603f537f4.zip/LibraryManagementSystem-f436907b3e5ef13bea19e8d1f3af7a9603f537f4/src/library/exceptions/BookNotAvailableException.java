package library.exceptions;

/**
 * Thrown when a book exists but has no copies currently available to issue.
 */
public class BookNotAvailableException extends Exception {
    public BookNotAvailableException(String message) {
        super(message);
    }
}
