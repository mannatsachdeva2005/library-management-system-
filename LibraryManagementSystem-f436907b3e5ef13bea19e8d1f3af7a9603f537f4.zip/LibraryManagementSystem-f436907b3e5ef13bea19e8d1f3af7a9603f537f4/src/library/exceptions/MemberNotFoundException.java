package library.exceptions;

/**
 * Thrown when a requested member is not registered in the system.
 */
public class MemberNotFoundException extends Exception {
    public MemberNotFoundException(String message) {
        super(message);
    }
}
