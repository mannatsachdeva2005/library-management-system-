package library.exceptions;

/**
 * Thrown when attempting to register a member or book that already exists.
 */
public class DuplicateEntryException extends Exception {
    public DuplicateEntryException(String message) {
        super(message);
    }
}
