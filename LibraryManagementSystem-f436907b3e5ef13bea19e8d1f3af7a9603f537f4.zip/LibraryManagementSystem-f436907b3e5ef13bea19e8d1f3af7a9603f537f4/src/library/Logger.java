package library;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;

/**
 * Minimal append-only logger satisfying the logging/monitoring
 * non-functional requirement. Every significant action in the
 * system (issue, return, registration, error) is timestamped and
 * appended to data/activity.log.
 */
public class Logger {
    private static final String LOG_PATH = "data/activity.log";

    public static void log(String message) {
        try (PrintWriter out = new PrintWriter(new FileWriter(LOG_PATH, true))) {
            out.println("[" + LocalDateTime.now() + "] " + message);
        } catch (IOException e) {
            System.err.println("[Logger] Failed to write log: " + e.getMessage());
        }
    }

    public static void error(String message) {
        log("ERROR: " + message);
    }
}
