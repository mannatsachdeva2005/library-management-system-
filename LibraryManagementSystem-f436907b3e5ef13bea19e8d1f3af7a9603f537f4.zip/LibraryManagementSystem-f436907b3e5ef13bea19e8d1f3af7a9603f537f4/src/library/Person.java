package library;

/**
 * Abstract base class capturing attributes common to every human actor
 * in the system (members and librarians). Subclasses provide their own
 * role-specific behaviour, demonstrating inheritance and polymorphism.
 */
public abstract class Person implements Persistable {
    protected String id;
    protected String name;
    protected String email;

    public Person(String id, String name, String email) {
        this.id = id;
        this.name = name;
        this.email = email;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    /**
     * Each subclass defines what role it plays in the library.
     */
    public abstract String getRole();

    @Override
    public String toString() {
        return String.format("%-8s %-20s %-15s %s", id, name, getRole(), email);
    }
}
