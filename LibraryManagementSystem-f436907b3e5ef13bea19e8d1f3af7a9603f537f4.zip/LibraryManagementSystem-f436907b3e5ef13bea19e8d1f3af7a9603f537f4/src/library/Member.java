package library;

/**
 * A library member who can borrow books. Enforces a maximum number
 * of books a member may hold at once.
 */
public class Member extends Person {
    public static final int MAX_BOOKS_ALLOWED = 3;

    private int booksIssuedCount;

    public Member(String id, String name, String email) {
        super(id, name, email);
        this.booksIssuedCount = 0;
    }

    // Constructor used when reloading from file, where the count is already known
    public Member(String id, String name, String email, int booksIssuedCount) {
        super(id, name, email);
        this.booksIssuedCount = booksIssuedCount;
    }

    public int getBooksIssuedCount() {
        return booksIssuedCount;
    }

    public boolean canBorrow() {
        return booksIssuedCount < MAX_BOOKS_ALLOWED;
    }

    public void incrementBooksIssued() {
        booksIssuedCount++;
    }

    public void decrementBooksIssued() {
        if (booksIssuedCount > 0) {
            booksIssuedCount--;
        }
    }

    @Override
    public String getRole() {
        return "Member";
    }

    @Override
    public String toFileLine() {
        return String.join("|", id, name, email, String.valueOf(booksIssuedCount));
    }

    /**
     * Reconstructs a Member from a saved file line.
     */
    public static Member fromFileLine(String line) {
        String[] parts = line.split("\\|");
        return new Member(parts[0], parts[1], parts[2], Integer.parseInt(parts[3]));
    }
}
