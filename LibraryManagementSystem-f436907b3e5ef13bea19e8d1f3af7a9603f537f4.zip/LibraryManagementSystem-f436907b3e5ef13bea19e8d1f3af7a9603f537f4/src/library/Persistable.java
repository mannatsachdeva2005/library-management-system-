package library;

/**
 * Contract implemented by every domain entity that can be written to
 * and reconstructed from the flat-file storage used by this system.
 * Demonstrates abstraction: each entity knows how to serialize itself,
 * the storage layer does not need to know the entity's internal fields.
 */
public interface Persistable {

    /**
     * @return a single pipe-delimited line representing this object,
     *         suitable for writing to a data file.
     */
    String toFileLine();
}
