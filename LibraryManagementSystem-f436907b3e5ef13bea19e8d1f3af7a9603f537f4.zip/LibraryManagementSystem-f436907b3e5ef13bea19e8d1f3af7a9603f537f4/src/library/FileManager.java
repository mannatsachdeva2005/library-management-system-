package library;

import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

/**
 * Generic helper for reading and writing pipe-delimited data files.
 * Keeping this separate from Library.java satisfies the single-
 * responsibility principle: this class only knows about files,
 * never about books/members/transactions directly.
 */
public class FileManager {

    /**
     * Writes every item's file-line representation to the given path,
     * one per line, overwriting any existing content.
     */
    public static <T extends Persistable> void writeAll(String path, List<T> items) {
        try {
            Path p = Paths.get(path);
            if (p.getParent() != null) {
                Files.createDirectories(p.getParent());
            }
            try (BufferedWriter writer = Files.newBufferedWriter(p)) {
                for (T item : items) {
                    writer.write(item.toFileLine());
                    writer.newLine();
                }
            }
        } catch (IOException e) {
            System.err.println("[FileManager] Could not write to " + path + ": " + e.getMessage());
        }
    }

    /**
     * Reads a file line by line and converts each line to an object
     * using the supplied parser. Returns an empty list if the file
     * does not exist yet (first run).
     */
    public static <T> List<T> readAll(String path, Function<String, T> parser) {
        List<T> result = new ArrayList<>();
        Path p = Paths.get(path);
        if (!Files.exists(p)) {
            return result;
        }
        try (BufferedReader reader = Files.newBufferedReader(p)) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isBlank()) {
                    result.add(parser.apply(line));
                }
            }
        } catch (IOException e) {
            System.err.println("[FileManager] Could not read " + path + ": " + e.getMessage());
        }
        return result;
    }
}
