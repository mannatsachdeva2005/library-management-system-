package library;

import library.exceptions.*;

import java.util.List;
import java.util.Scanner;

/**
 * Menu-driven console interface. Kept deliberately thin: it only
 * handles input/output and delegates every real decision to the
 * Library engine, so the UI layer and business logic stay decoupled.
 */
public class Main {
    private static final Scanner sc = new Scanner(System.in);
    private static final Library library = new Library();

    public static void main(String[] args) {
        System.out.println("=========================================");
        System.out.println(" Library Management System");
        System.out.println("=========================================");

        boolean running = true;
        while (running) {
            printMenu();
            String choice = sc.nextLine().trim();
            try {
                switch (choice) {
                    case "1": addBook(); break;
                    case "2": searchBooks(); break;
                    case "3": listBooks(); break;
                    case "4": registerMember(); break;
                    case "5": listMembers(); break;
                    case "6": issueBook(); break;
                    case "7": returnBook(); break;
                    case "8": viewMemberLoans(); break;
                    case "9": removeBook(); break;
                    case "0": running = false; System.out.println("Goodbye!"); break;
                    default: System.out.println("Invalid option, please try again.");
                }
            } catch (BookNotFoundException | MemberNotFoundException
                     | BookNotAvailableException | DuplicateEntryException e) {
                System.out.println("Error: " + e.getMessage());
                Logger.error(e.getMessage());
            } catch (NumberFormatException e) {
                System.out.println("Error: please enter a valid number.");
            } catch (IllegalStateException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void printMenu() {
        System.out.println("\n--- Menu ---");
        System.out.println("1. Add Book");
        System.out.println("2. Search Books by Title");
        System.out.println("3. List All Books");
        System.out.println("4. Register Member");
        System.out.println("5. List All Members");
        System.out.println("6. Issue Book");
        System.out.println("7. Return Book");
        System.out.println("8. View a Member's Active Loans");
        System.out.println("9. Remove Book");
        System.out.println("0. Exit");
        System.out.print("Choose an option: ");
    }

    private static void addBook() throws DuplicateEntryException {
        System.out.print("ISBN: ");
        String isbn = sc.nextLine().trim();
        System.out.print("Title: ");
        String title = sc.nextLine().trim();
        System.out.print("Author: ");
        String author = sc.nextLine().trim();
        System.out.print("Genre: ");
        String genre = sc.nextLine().trim();
        System.out.print("Number of copies: ");
        int copies = Integer.parseInt(sc.nextLine().trim());

        if (isbn.isEmpty() || title.isEmpty() || copies <= 0) {
            System.out.println("ISBN and title are required, and copies must be positive.");
            return;
        }

        library.addBook(new Book(isbn, title, author, genre, copies, copies));
        System.out.println("Book added successfully.");
    }

    private static void searchBooks() {
        System.out.print("Enter a title keyword: ");
        String keyword = sc.nextLine().trim();
        List<Book> results = library.searchByTitle(keyword);
        if (results.isEmpty()) {
            System.out.println("No matching books found.");
        } else {
            results.forEach(System.out::println);
        }
    }

    private static void listBooks() {
        List<Book> books = library.allBooksSorted();
        if (books.isEmpty()) {
            System.out.println("Catalog is empty.");
        } else {
            books.forEach(System.out::println);
        }
    }

    private static void registerMember() throws DuplicateEntryException {
        System.out.print("Member ID: ");
        String id = sc.nextLine().trim();
        System.out.print("Name: ");
        String name = sc.nextLine().trim();
        System.out.print("Email: ");
        String email = sc.nextLine().trim();

        if (id.isEmpty() || name.isEmpty()) {
            System.out.println("Member ID and name are required.");
            return;
        }

        library.registerMember(new Member(id, name, email));
        System.out.println("Member registered successfully.");
    }

    private static void listMembers() {
        List<Member> all = library.allMembers();
        if (all.isEmpty()) {
            System.out.println("No members registered yet.");
        } else {
            all.forEach(System.out::println);
        }
    }

    private static void issueBook() throws BookNotFoundException, MemberNotFoundException, BookNotAvailableException {
        System.out.print("ISBN to issue: ");
        String isbn = sc.nextLine().trim();
        System.out.print("Member ID: ");
        String memberId = sc.nextLine().trim();

        Transaction txn = library.issueBook(isbn, memberId);
        System.out.println("Issued. Transaction ID: " + txn.getTransactionId()
                + " | Due date: " + txn.getDueDate());
    }

    private static void returnBook() throws BookNotFoundException, MemberNotFoundException {
        System.out.print("Transaction ID: ");
        String txnId = sc.nextLine().trim();

        double fine = library.returnBook(txnId);
        if (fine > 0) {
            System.out.printf("Book returned. Overdue fine: %.2f%n", fine);
        } else {
            System.out.println("Book returned on time. No fine.");
        }
    }

    private static void viewMemberLoans() throws MemberNotFoundException {
        System.out.print("Member ID: ");
        String memberId = sc.nextLine().trim();
        library.findMember(memberId); // validates the member exists

        List<Transaction> loans = library.activeLoansForMember(memberId);
        if (loans.isEmpty()) {
            System.out.println("No active loans for this member.");
        } else {
            loans.forEach(System.out::println);
        }
    }

    private static void removeBook() throws BookNotFoundException {
        System.out.print("ISBN to remove: ");
        String isbn = sc.nextLine().trim();
        library.removeBook(isbn);
        System.out.println("Book removed.");
    }
}
