package library;

/**
 * A staff member who administers the catalog. Kept separate from
 * Member to show how a shared Person hierarchy can support distinct
 * roles with different permissions in a larger version of this system.
 */
public class Librarian extends Person {

    private String staffCode;

    public Librarian(String id, String name, String email, String staffCode) {
        super(id, name, email);
        this.staffCode = staffCode;
    }

    public String getStaffCode() {
        return staffCode;
    }

    @Override
    public String getRole() {
        return "Librarian";
    }

    @Override
    public String toFileLine() {
        return String.join("|", id, name, email, staffCode);
    }

    public static Librarian fromFileLine(String line) {
        String[] parts = line.split("\\|");
        return new Librarian(parts[0], parts[1], parts[2], parts[3]);
    }
}
